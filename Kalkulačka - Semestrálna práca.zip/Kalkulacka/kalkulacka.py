from flask import Flask, render_template, request, jsonify
import ast
import operator as op

app = Flask(__name__, static_folder='static', template_folder='templates')

_ALLOWED_OPERATORS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.Mod: op.mod,
    ast.UAdd: lambda x: x,
    ast.USub: lambda x: -x,
}

def safe_eval(expr: str):
    """
    Bezpečne vyhodnotí aritmetický výraz obsahujúci:
    čísla, + - * / % **, zátvorky, unárne +/-
    Hodí ValueError pri neplatnom výraze.
    """
    try:
        parsed = ast.parse(expr, mode='eval')
        return _eval_node(parsed.body)
    except ZeroDivisionError as e:
        raise ValueError("Delenie nulou")
    except Exception as e:
        raise ValueError("Neplatný výraz")

def _eval_node(node):
    if isinstance(node, ast.Num):
        return node.n
    if hasattr(ast, "Constant") and isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError("Nepodporovaný typ konštanty")
    if isinstance(node, ast.BinOp):
        if type(node.op) not in _ALLOWED_OPERATORS:
            raise ValueError("Nepovolený operátor")
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        return _ALLOWED_OPERATORS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp):
        if type(node.op) not in _ALLOWED_OPERATORS:
            raise ValueError("Nepovolený unárny operátor")
        operand = _eval_node(node.operand)
        return _ALLOWED_OPERATORS[type(node.op)](operand)
    if isinstance(node, ast.Expr):
        return _eval_node(node.value)
    raise ValueError("Nepodporovaný konštrukt")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/calculate", methods=["POST"])
def calculate():
    data = request.get_json(force=True)
    expr = data.get("expression", "")
    expr = expr.strip()
    if not expr:
        return jsonify({"error": "Prázdny výraz"}), 400
    try:
        result = safe_eval(expr)
        if isinstance(result, float) and result.is_integer():
            result = int(result)
        return jsonify({"result": result})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

if __name__ == "__main__":
    app.run(debug=True)
